export default {
  template: `
  <div>
    <slot>header</slot>
  </div>`
}