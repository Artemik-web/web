export default {
  template: `<h2>思诚科技</h2>`
}