export default {
  template: `<h2>导航组件</h2>`
}