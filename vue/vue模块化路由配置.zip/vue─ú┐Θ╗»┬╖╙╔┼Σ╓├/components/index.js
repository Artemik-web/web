import Header from './Header.js';
import Logo from './Logo.js';
import Nav from './Nav.js';

export default {

  install( Vue ){
    Vue.component('GxHeader', Header);
    Vue.component('GxLogo', Logo);
    Vue.component('GxNav', Nav);
  }

}