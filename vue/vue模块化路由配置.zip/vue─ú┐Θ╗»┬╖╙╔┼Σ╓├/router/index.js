import VueRouter from '../js/vue-router_esm.js';

import Home from '../views/Home.js';
import About from '../views/About.js';

const router = new VueRouter({
  linkActiveClass: 'active',
  linkExactActiveClass: 'exact-active',
  routes: [
    {path: '/', redirect: '/home'},
    {path: '/home', component: Home},
    {path: '/about', component: About},
  ]
})

export default router;