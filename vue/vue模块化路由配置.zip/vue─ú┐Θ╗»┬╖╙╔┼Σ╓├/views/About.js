export default {
  template: `
  <h3>我是关于页面</h3>
  `
}