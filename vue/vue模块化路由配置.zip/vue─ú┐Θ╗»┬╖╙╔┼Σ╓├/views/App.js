export default {
  template: `
  <div class="app">
    <gx-header>
      <gx-logo></gx-logo>
      <p>
        <router-link to="/home">首页</router-link>
        <router-link to="/about">关于</router-link>
      </p>
    </gx-header>
    <router-view></router-view>
  </div>
  `
}