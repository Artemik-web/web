export default {
  template: `
  <h3>我是首页页面</h3>
  `
}